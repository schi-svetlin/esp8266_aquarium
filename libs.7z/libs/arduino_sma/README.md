# arduino-sma
Simple moving average filter for arduino
