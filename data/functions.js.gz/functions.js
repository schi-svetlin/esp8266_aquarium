let but = []; 
let mes = []; 
let sch_title = [[],[]];

let defaultLang;
let restartMessage;
let restartTitle;
window.onload = function() {  
    openValues(); 
	liveValues();
    init();
    updateChart();	
};
function changeLang(selectedLang) {
	event.preventDefault();
    openlang(selectedLang);
	let jsonData = 'defaultLang=' + selectedLang;
	let xhttp = new XMLHttpRequest();
	xhttp.open("GET", "lang?"+jsonData, true);
	xhttp.send();	
}

function openSchedule() {
	event.preventDefault();
	let selIndex = document.getElementById("select_schedule").options.selectedIndex;	
	let xhttp = new XMLHttpRequest();
	xhttp.open("GET", 'configSetup.json', true);
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			let configSetup = JSON.parse(this.responseText);	
			for (let i = 0; i <= 5; ++i) {
				document.getElementById('sch_title'+(parseInt(i))).value = sch_title[selIndex][i];
			}
			for (let i = 0; i <= 6; i++) {
				for (let j = 0; j <= 3; j++) {
					document.getElementById('schedule'+(parseInt(i))+(parseInt(j))).value = configSetup.schedule[selIndex][i][j];
				}
			}			
		}
	};
	xhttp.send();
}

function openlang(lng) {
    let lang_path = lng+'.json';
	let selIndex = document.getElementById("select_schedule").options.selectedIndex;	
	let xhttp = new XMLHttpRequest();
	xhttp.open("GET", lang_path, true);
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			let configSetup = JSON.parse(this.responseText);
			document.querySelector("label[for=tab_0").innerHTML = configSetup.tab[0];
			document.querySelector("label[for=tab_1").innerHTML = configSetup.tab[1];
			document.querySelector("label[for=tab_2").innerHTML = configSetup.tab[2];
			document.querySelector("label[for=tab_3").innerHTML = configSetup.tab[3];
			document.getElementById("text_s0").innerHTML = "&nbsp;&nbsp;&nbsp;" + configSetup.sch_title[0][0];
			document.getElementById("text_s1").innerHTML = "&nbsp;&nbsp;&nbsp;" + configSetup.sch_title[0][1];
			for (let i = 0; i <= 21; i++)  { document.getElementById('text'+(parseInt(i))).innerHTML = configSetup.text_h[i]; }
			for (let i = 9; i <= 11; i++)  { document.getElementById('input'+(parseInt(i))).title = configSetup.text_h[23];   }
			for (let i in configSetup.but) { but[i] = configSetup.but[i]; }
			for (let i in configSetup.mes) { mes[i] = configSetup.mes[i]; }
			for (let i = 0; i <= 5; i++) {
				sch_title[0][i] = configSetup.sch_title[1][i];
				sch_title[1][i] = configSetup.sch_title[2][i];
				document.getElementById('sch_title'+(parseInt(i))).value = sch_title[selIndex][i];
			}

			restartMessage = configSetup.text_h[22];
			document.getElementById("text18").value = configSetup.text_h[18];
			document.getElementById("Button1").value = but[5];
			document.getElementById("Button2").value = but[6];
			document.getElementById("Button3").value = but[6];
			document.getElementById("Button4").value = but[3];			
			document.getElementById("Button5").value = but[4];	
			document.getElementById("Button6").innerHTML = but[7];
			document.getElementById("Button7").value = but[8];
			document.getElementById("Button8").value = but[9];	
		}
	footerMessage('[GET]: Статус загрузки данных: ', this.status, 4000);		
	};
	xhttp.send();	
}

function openValues(){
    let selectList = document.getElementById("select_lang");
	let selIndex = document.getElementById("select_schedule").options.selectedIndex;	
	let xhttp = new XMLHttpRequest();
    xhttp.open("GET", 'configSetup.json', true);
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			let configSetup = JSON.parse(this.responseText);
			for (let i in configSetup.lang){
				let option = document.createElement("option");
				option.value = configSetup.lang[i];
				option.text = configSetup.lang[i];
				selectList.appendChild(option);
			}
			document.getElementById("text_t1").innerText='ver: ' + configSetup.ver;
			selectList.value = configSetup.defaultLang;
			openlang(selectList.value);
			for (let i in configSetup.input) { document.getElementById('input'+(parseInt(i))).value = configSetup.input[i]; }
			for (let i = 0; i <= 5; i++) { document.getElementById('sch_title'+(parseInt(i))).value = sch_title[selIndex][i] }
			for (let i = 0; i <= 6; i++) {
				for (let j = 0; j <= 3; j++) {
					document.getElementById('schedule'+(parseInt(i))+(parseInt(j))).value = configSetup.schedule[selIndex][i][j];
				}
			}
		}
	footerMessage('[GET]: Статус загрузки данных: ', this.status, 4000);	
	};
xhttp.send();
}

function ButtonClick(buttonNumb, url, setText) {
	let message = new Object();	
	message.loading = but[0];
	message.success = but[1];
	message.failure = but[2];
	let xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			console.warn(message.success);
			footerMessage('[GET]: Статус отправки данных: ', this.status, 4000);			
			buttonNumb.value = message.success;
			buttonNumb.setAttribute("class", "btn btn-success");	
			setTimeout(() => { 
				buttonNumb.value = setText;
				buttonNumb.setAttribute("class", "btn btn-primary");			
			}, 1000);
		} else if (this.readyState < 4){
			console.warn(message.loading);
			buttonNumb.value = message.loading;
			buttonNumb.setAttribute("class", "btn btn-warning");	
		} else {
			console.warn(message.failure);
			footerMessage('[GET]: Статус отправки данных: ', this.status, 4000);				
			buttonNumb.value = message.failure;
			buttonNumb.setAttribute("class", "btn btn-danger");	
			setTimeout(() => { 
				buttonNumb.setAttribute("class", "btn btn-primary");
				buttonNumb.value = setText;
			}, 1000);
		}
	};
	xhttp.open("GET", url, true);
	xhttp.send();
}

function init(){
	let button1 = document.getElementById("Button1");
	let button2 = document.getElementById("Button2");
	let button3 = document.getElementById("Button3");
	let button4 = document.getElementById("Button4");
	let button5 = document.getElementById("Button5");
	let button6 = document.getElementById("Button6");   
	let button7 = document.getElementById("Button7");
	button1.addEventListener("click", function(event){ 
		let sched = [[],[],[],[],[],[],[],[]];
		let selIndex = document.getElementById("select_schedule").options.selectedIndex;
		let jsonData = '';
		event.preventDefault(); 
		for (let i = 0; i <= 6; i++) {
			for (let j = 0; j <= 3; j++) {
				sched[i][j] = document.getElementById('schedule'+(parseInt(i))+(parseInt(j))).value;
				jsonData += 'schedule['+selIndex+']['+i+']['+j+']='+sched[i][j]+'&';
			}
		}
		ButtonClick(button1, 'save_schedule?selIndex='+selIndex+'&'+jsonData.substring(0, jsonData.length-1), but[5]); 
		
	});
	button2.addEventListener("click", function(event){ 
		let jsonData = '';
		event.preventDefault(); 
		for (let i = 0; i <= 6; i++) {
			jsonData += 'input['+i+']='+document.getElementById('input'+(parseInt(i))).value+'&';
		}
		ButtonClick(button2, 'save?'+jsonData.substring(0, jsonData.length-1), but[6]); 
	});		
	button3.addEventListener("click", function(event){ 
		let jsonData = '';
		event.preventDefault(); 
		for (let i = 7; i <= 11; i++) {
			jsonData += 'input['+i+']='+document.getElementById('input'+(parseInt(i))).value+'&';
		}
		ButtonClick(button3, 'ssid?'+jsonData.substring(0, jsonData.length-1), but[6]); 
	});	
	button4.addEventListener("click", function(event){ 
		event.preventDefault(); 
		let jsonData = 'input[12]=' + document.getElementById("input12").value + '&input[13]=' + document.getElementById("input13").value;
		ButtonClick(button4, 'save_date?'+jsonData, but[3]); 
	});
	button5.addEventListener("click", function(event){ 
		event.preventDefault(); 
		let jsonData = 'input[14]=' + document.getElementById("input14").value;
		ButtonClick(button5, 'auto_sync?'+jsonData, but[4]); 
	});	

}

function liveValues() {
    ws = new WebSocket("ws://" + window.location.hostname+":81/");
    ws.onopen = function(event) {
		console.log("[OPEN] Websocket-соединение установлено...");
		footerMessage("[OPEN] Websocket-соединение установлено...", 0, 4000);
	};
    ws.onmessage = function(event) {
		//console.log("[message] Данные с сервера получены");
		//console.log(event.data);
		let json = JSON.parse(event.data);
		let parsed_day, parsed_month, parsed_year, parsed_hour, parsed_min;
		parsed_day = json.now.substring(0, 2);
		parsed_month = json.now.substring(3, 5);
		parsed_year = json.now.substring(6, 10);
		parsed_hour = json.now.substring(13, 15);
		parsed_min = json.now.substring(16, 18);		
        if (parsed_day < 1 || parsed_day > 31 || parsed_month < 1 || parsed_month > 12 || parsed_hour < 0 || parsed_hour > 24 || parsed_min < 0 || parsed_min > 60){
            if (parsed_day == 165 || parsed_month == 165 || parsed_hour == 165 || parsed_min == 85) {
				document.getElementById("text_t3").innerHTML = mes[1];
				document.getElementById("text_t3").style="color:red;font-size:20px;width:65%;text-align:center;vertical-align:middle;display:table-cell;";
				console.log(json.now);
			} else {
				document.getElementById("text_t3").innerHTML = mes[2];
				document.getElementById("text_t3").style="color:red;font-size:20px;width:65%;text-align:center;vertical-align:middle;display:table-cell;";
				console.log(json.now);
			} 
		} else {
			document.getElementById("text_t3").innerHTML = json.now;
            document.getElementById("text_t3").style="color:white;font-size:20px;width:65%;text-align:center;vertical-align:middle;display:table-cell;";
		}
		if       (json.rssi >= -50) 					  { class_wifi = 'wifi4'; } 
		else if ((json.rssi >= -70) && (json.rssi < -50)) { class_wifi = 'wifi3'; } 
		else if ((json.rssi >= -85) && (json.rssi < -70)) {	class_wifi = 'wifi2'; } 
		else if ((json.rssi >= -110) && (json.rssi < -85)){ class_wifi = 'wifi1'; }
		if (json.led === 0) { class_led = 'led_0'; } 
		else 			   { class_led = 'led_1'; }
		class_fan = 'fan_' + json.fan;
		class_ten = 'ten_' + json.ten;
		class_relay1 = 'relay1_' + json.rel1;
		class_relay2 = 'relay2_' + json.rel2;
        document.getElementById("Picture2").setAttribute("class", class_wifi);
        document.getElementById("Picture3").setAttribute("class", class_led);
        document.getElementById("Picture4").setAttribute("class", class_fan);        
		document.getElementById("Picture5").setAttribute("class", class_ten);	
        document.getElementById("Picture6").setAttribute("class", class_relay1);        
		document.getElementById("Picture7").setAttribute("class", class_relay2);	
		document.getElementById("text_t5").innerHTML = json.led+"%";		
		document.getElementById("text_t4").innerHTML = json.rssi+" dBm";	
		if (json.temp === 0.0){
			document.getElementById("text_t2").innerHTML = mes[0];		
		    document.getElementById("Picture1").setAttribute("class", "tempna");	
		}
		else{
			document.getElementById("text_t2").innerHTML = json.temp + " °C";	
		    document.getElementById("Picture1").setAttribute("class", "temp");
		}
		if (json.graph_changing == 1){
			ws.send(0);	
			updateChart();
		}
	};
    ws.onclose = function(event) {
		ws = null;
		console.log("[CLOSE] Websocket-соединение разорвано cо статусом: " + event.code);
		footerMessage('[CLOSE] Websocket-соединение разорвано cо статусом: ', event.code, 4000);
    };	
    ws.onerror = function(event) {
		console.log("[ERROR] Ошибка подключения...");
		footerMessage("[ERROR] Ошибка подключения...", event.code, 4000);
    };
};

function footerMessage(message, statusCode, delay) {
    let state = '';
	switch(statusCode) {
	    case   0:  state = ""; break;
	    case 200:  state = "OK"; break;
	    case 400:  state = "BAD REQUEST"; break;
	    case 403:  state = "FORBIDDEN"; break;
	    case 404:  state = "NOT FOUND"; break;
	    case 502:  state = "BAD GATEWAY"; break;		
	    case 503:  state = "SERVICE UNAVAILABLE"; break;	
	    case 504:  state = "GATEWAY TIMEOUT"; break;	
	    case 1000: state = "[1000] CLOSED NORMALLY"; break;	
	    case 1001: state = "[1001] SERVER GOING DOWN"; break;	
	    case 1002: state = "[1002] PROTOCOL ERROR"; break;
	    case 1003: state = "[1003] CAN\'T ACCEPT RECEIVED DATA"; break;
	    case 1004: state = "[1004]"; break;
	    case 1005: state = "[1005] NO STATUS CODE"; break;		
	    case 1006: state = "[1006] CLOSED ABNORMALLY"; break;	
	    case 1007: state = "[1007] DATA WITHIN MESSAGE"; break;	
	    case 1008: state = "[1008] MESSAGE THAT \"VIOLATES ITS POLICY\""; break;	
	    case 1009: state = "[1009] TOO BIG MESSAGE"; break;	
	    case 1010: state = "[1010]"; break;	
	    case 1011: state = "[1011]"; break;	
	    case 1015: state = "[1015] FAILURE TO PERFORM  A TLS HANDSHAKE"; break;			



		
	}	
	document.getElementById("reason").value = message + state;	
	setTimeout(() => { document.getElementById("reason").value = "";}, delay);	
 }	 
	 
 function updateChart() {
	let xhttp = new XMLHttpRequest();
	xhttp.open("GET", "configChart.json", true);
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			let jsonfile = JSON.parse(this.responseText);
			
 			let json_val = {'values_filtered': []};
			for (let i in jsonfile.date) {
				json_val.values_filtered.push({ 'meta': jsonfile.date[i], 'value': jsonfile.values_filtered[i]});
			} 

			var chart = new Chartist.Line('.ct-chart', {
			    labels: jsonfile.date,
			    series: [json_val.values_filtered]
			}, {
				width: '500px',
				height: '400px',
				fullWidth: true, 
			    plugins: [
					Chartist.plugins.tooltip({
						pointClass: 'my-cool-point',
						appendToBody: true,
						tooltipOffset: {
							x: 56,
							y: 0
						}
					})
			    ]
			});
 			
			chart.on('draw', function(data) {
			  if(data.type === 'point') {
				var circle = new Chartist.Svg('circle', {
				  cx: [data.x],
				  cy: [data.y],
				  r: [5], 
				  'ct:value': data.value.y,
				  'ct:meta': data.meta,
				  style: 'pointer-events: all !important',
				  class: 'my-cool-point',
				}, 'ct-area');
				data.element.replace(circle);
			  }
			});
		}
	};
	xhttp.send();
};




/* function add_zero(n) {return n > 9 ? n: "0" + n; } */


let eventType = 0;	
document.addEventListener('touchstart', handleTouchStart, false);
document.addEventListener('touchmove', handleTouchMove, false);
document.addEventListener('touchend', handleTouchEnd, false);
let xDown = null;
let yDown = null;
let xDiff = null;
let yDiff = null;
let timeDown = null;
let startEl = null;

function handleTouchEnd(e) {
    if (startEl !== e.target) return;
    let swipeThreshold = 200; /* расстояние касания default 10px */
    let swipeTimeout = 1000;  /* время касания default 1000ms    */
    let timeDiff = Date.now() - timeDown;
    if (Math.abs(xDiff) > Math.abs(yDiff)) { // most significant
        if (Math.abs(xDiff) > swipeThreshold && timeDiff < swipeTimeout) {
            if (xDiff > 0) {
                eventType ++;				
				if (eventType > 3) eventType = 0;
            }
            else {
                eventType --;	
				if (eventType < 0) eventType = 3;
            }
        }
		document.getElementById('tab_'+ eventType).checked = true;		
    }
/*     else {
        if (Math.abs(yDiff) > swipeThreshold && timeDiff < swipeTimeout) {
            if (yDiff > 0) {
                //eventType = 'swiped-up';
                //document.getElementById("text_t1").innerText = 'up';
            }
            else {
                //eventType = 'swiped-down';
                //document.getElementById("text_t1").innerText = 'down';
            }
        }
    } */
    if (eventType !== '') {
        startEl.dispatchEvent(new CustomEvent(eventType, { bubbles: true, cancelable: true }));
    }
    xDown = null;
    yDown = null;
    timeDown = null;
};

function handleTouchStart(e) {
    if (e.target.getAttribute('data-swipe-ignore') === 'true') return;
    startEl = e.target;
    timeDown = Date.now();
    xDown = e.touches[0].clientX;
    yDown = e.touches[0].clientY;
    xDiff = 0;
    yDiff = 0;
};

function handleTouchMove(e) {
    if (!xDown || !yDown) return;
    let xUp = e.touches[0].clientX;
    let yUp = e.touches[0].clientY;
    xDiff = xDown - xUp;
    yDiff = yDown - yUp;
};

